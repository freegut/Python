# Определение класса пропуска
class Pass:
    def __init__(self, last_name, first_name, middle_name, faculty):
        self.last_name = last_name
        self.first_name = first_name
        self.middle_name = middle_name
        self.faculty = faculty

    # Класс пропуска преподавателя, наследуется от класса пропуска


class TeacherPass(Pass):
    def __init__(self, last_name, first_name, middle_name, faculty, department):
        super().__init__(last_name, first_name, middle_name, faculty)
        self.department = department

    # Класс пропуска студента, наследуется от класса пропуска


class StudentPass(Pass):
    def __init__(self, last_name, first_name, middle_name, faculty, entrance_year):
        super().__init__(last_name, first_name, middle_name, faculty)
        self.entrance_year = entrance_year

    # Создание объектов пропусков преподавателей и студентов


teacher_passes = [
    TeacherPass("Иванов", "Иван", "Иванович", "Информационные технологии", "Программирования"),
    TeacherPass("Петров", "Петр", "Петрович", "Экономика", "Финансов")
]

student_passes = [
    StudentPass("Сидоров", "Сидор", "Сидорович", "Экономика", 2023),
    StudentPass("Андреев", "Андрей", "Андреевич", "Информационные технологии", 2024)
]

# Создание массива объектов пропусков
register = teacher_passes + student_passes

# Вывод информации о пропусках студентов
print("Информация о пропусках студентов:")
for pass_ in student_passes:
    print(
        f"{pass_.last_name} {pass_.first_name} {pass_.middle_name}, факультет: {pass_.faculty}, год поступления: {pass_.entrance_year}")

# Определение количества пропусков для аннулирования (в данном случае всех пропусков выпускников)
num_to_annul = len([pass_ for pass_ in student_passes if pass_.entrance_year <= 2024])
print(f"Количество пропусков для аннулирования: {num_to_annul}")