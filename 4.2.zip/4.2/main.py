from colorama import init

init()

from colorama import Fore, Back, Style

# Определение класса Транспорт
class Vehicle:
    def __init__(self, ID, Brand, Power, Price):
        self.ID = ID
        self.Brand = Brand
        self.Power = Power
        self.Price = Price

# Класс Самолет, наследуется от класса Транспорт
class Aircraft(Vehicle):
    def __init__(self, ID, Brand, Power, Price, MaxFlightAltitude):
        super().__init__(ID, Brand, Power, Price)
        self.MaxFlightAltitude = MaxFlightAltitude

# Класс Автомобиль, наследуется от класса Транспорт
class Car(Vehicle):
    def __init__(self, ID, Brand, Power, Price, Mileage, HasTechnicalInspection):
        super().__init__(ID, Brand, Power, Price)
        self.Mileage = Mileage
        self.HasTechnicalInspection = HasTechnicalInspection

# Создание экземпляров машин и самолетов
cars = [Car("1", "бэнтли", 200, 100, 100500, "Присутствует"),
        Car("2", "мазерати", 150, 200, 200500, "Отсутствует")]
aircrafts = [Aircraft("1", "пердолёт", 100, 150, 200),
             Aircraft("2", "газ", 200, 300, 300)]

# Вывод информации о машинах
print(f"Машина {cars[0].ID}. Цена = {cars[0].Price}, пробег = {cars[0].Mileage}")
print(f"Налог на машины: {sum(car.Price * 0.05 for car in cars)}")

# Поиск самой дорогой машины
expensiveCar = cars[0]
for car in cars:
    if expensiveCar.Price < car.Price:
        expensiveCar = car
print('\033[31m' + f"Техосмотр самой дорогой машины: {expensiveCar.HasTechnicalInspection}")

# Вывод информации о самолетах
print('\033[39m'f"Налог на самолеты: {sum(aircraft.Price * 0.03 for aircraft in aircrafts)}")

# Поиск самого дорогого самолета
expensiveAircraft = aircrafts[0]
for aircraft in aircrafts:
    if expensiveAircraft.Price < aircraft.Price:
        expensiveAircraft = aircraft
print(f"Дорогой самолет: мощность - {expensiveAircraft.Power}, цена - {expensiveAircraft.Price}, марка - {expensiveAircraft.Brand}")

# Вывод списка машин и самолетов
print("Все машины:")
for car in cars:
    print(f"Машина {car.ID}, марка: {car.Brand}, мощность: {car.Power}, цена: {car.Price}, пробег: {car.Mileage}, техосмотр: {car.HasTechnicalInspection}")

print("Все самолеты:")
for aircraft in aircrafts:
    print(f"Самолет {aircraft.ID}, марка: {aircraft.Brand}, мощность: {aircraft.Power}, цена: {aircraft.Price}, максимальная высота: {aircraft.MaxFlightAltitude}")